# Write a function square(num) that returns the square of a number.

def square(num=10):
    return num**2

print(square(3))