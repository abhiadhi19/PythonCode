# Functions Basic 

def sumFunc() :
    a=4
    b=8
    sum=a+b
    print(sum)


sumFunc() # print 12 
# Function Calling 

# # .... 100 line of code

sumFunc() # print 12 

# # .... 100 line of code

sumFunc() # print 12 