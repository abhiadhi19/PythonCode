# Write a function named welcome_message() that prints “Welcome to
# Python Programming!” three times.


# Simple Func Definituon without any Param
def welcome_message():
    print("Welcome to Python Course by Saumya")
    print("Line 2")
  

welcome_message() #function is being called 
welcome_message() #function is being called 
welcome_message() #function is being called

# Define a function inspire() that prints a motivational quote with your
# name.

# FUNCTION DEFINITION , we have only defined the function here 
def inspire():
    print("You are the master of your destiny: Saumya Singh")

inspire()

# Simple Function Call with No Argument
def IamBest():
    print("Just a Trial Function")

IamBest()