# Return Statement 

def multiply(a=10, b=10):
    return a*b

print(multiply(10, 10))
result= multiply(5, 10)
print(result)

