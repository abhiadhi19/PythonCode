str= "Saumya singh"
print(str.upper())
print(str.lower())
print(str.title())
print(str.find("ng"))
print(str.replace("singh", "Best"))
print(str.count("a")) #count the occurence 

#escape sequence 

print("Hello World")
print("Hello\nWorld")
print("Hello \t World")
