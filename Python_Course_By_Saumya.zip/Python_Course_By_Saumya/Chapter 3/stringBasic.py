str1= 'Hello'
str2= "Saumya"
str3= '''Python Course by Saumya Di'''

print(str1)
print(str2)
print(str3)

# string concatenation 
print(str1 + " " + str2)

#length of string 
print( len(str1))


