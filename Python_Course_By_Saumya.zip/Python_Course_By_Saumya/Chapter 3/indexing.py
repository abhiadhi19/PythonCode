str1= "Divya's name is very nice"
length= len(str1) 
print(length) #5
print(str1[0]) #D
print(str1[4]) #a




