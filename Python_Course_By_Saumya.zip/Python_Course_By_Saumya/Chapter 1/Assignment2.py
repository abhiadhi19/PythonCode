# Question - Take diameter as input and calculate the area of a circle.


diameter = int(input("Inter the value of diameter: "))
radius = diameter/2
area = 3.14 * (radius ** 2)
print("Radius of the circle is", radius)
print("Area of circle is", area)
