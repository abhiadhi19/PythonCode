# Program to take input from the user 

print("A sample program to understand input method in python")

name= input("Enter your good name :")

print("Your good name is :", name)

