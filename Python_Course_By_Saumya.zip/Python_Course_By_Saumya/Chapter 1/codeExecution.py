name = "Saumya Singh"
age1 = 25
age2 = 40
print("Actual Value:" , age2)
favSubject = "Maths"
age2 = age1
print("Changed Value:" , age2)



