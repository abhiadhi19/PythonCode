file= open("mast.txt", "r")
data= file.read()

print("Data of the file is: ", data)