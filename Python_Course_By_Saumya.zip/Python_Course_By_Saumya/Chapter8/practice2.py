# Open a file called report.txt in write mode.

file= open("report87979768.txt", "x")
file.write("Mai toh majak kar rahi thi")

 