# while loop and for loop
# print the name 100 times 

num = 1

while num<=5:
    print("Saumya Singh")
    num= num+1

print("Now we are out of the while loop")

'''
num= 1 Saumya Singh
2 Saumya Singh
3 Saumya Singh
4 Saumya Singh
num= 5  Saumya Singh
"Now we are out of the while loop
'''
