foodList= ["cake", "mango", "pizza"]

for item in foodList:
    print(item)

collegesTuple = ("NIT-Delhi", "ABES", "BBAU", "IIT-D", "IIT-H")

for eachItem in collegesTuple:
    print("Colleges Visited by Saumya" , eachItem)