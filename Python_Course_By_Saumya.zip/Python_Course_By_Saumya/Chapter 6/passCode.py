for i in range(1,7):
    pass