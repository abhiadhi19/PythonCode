# range(start, stop, step)

for item in range(2, 21, 10):
    print(item)



  