# Write a Python program to print numbers from 1 to 10 using a while loop.

i= 1

while (i<=10):
    print(i)
    i+=1

print("Quest 1 complete")
   

# Write a program to print numbers from 10 down to 1 using a while loop.

j=10
while (j>=1):
    print(j)
    j=j-1
    print("j =", j)

print("Quest 2 complete")


