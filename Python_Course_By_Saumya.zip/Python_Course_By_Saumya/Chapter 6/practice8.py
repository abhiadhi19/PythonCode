# Write a program using for and range() to print all even numbers between 1
# and 20.

for i in range(2, 21, 2):
    print(i)