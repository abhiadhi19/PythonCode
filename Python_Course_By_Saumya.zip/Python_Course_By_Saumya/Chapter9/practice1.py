# Create a class Car with attribute brand = "Scorpio".

class Car:
    brand= "Scorpio"

obj1= Car()
print("Brand name is - ", obj1.brand)