# Lists in Python 

food= ["chole bathure", "choco waffle", "gulab jamun", "apple", "mango", 7]
print(len(food))

print("First Value of the list:", food[0])
print("First Value of the list:", food[3])
