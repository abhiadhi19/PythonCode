# take 3 food and store in list, print list and length

food1= input("Enter food 1:")
food2= input("Enter food 2:")
food3= input("Enter food 3:")

foodList= []
foodList.append(food1)
foodList.append(food2)
foodList.append(food3)


print(foodList)
print(len(foodList))
