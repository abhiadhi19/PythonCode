#conditional statements 

# marks= 95

# if(marks >= 90):
#     print("Your grade is A") 
# elif(marks >= 80):
#     print("Your grade is B") 

age= 16

if(age>=18):
    print("You are eligible to vote")
else:
    print("You are not eligible to vote")

print("My code ends here")