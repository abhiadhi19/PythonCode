# take input and print posotive if num is greater than zero and so on 

num= int(input("Enter a number :"))

if(num>0):
    print("Positive")
elif(num==0):
    print("Zero")
else:
    print("Negative")

