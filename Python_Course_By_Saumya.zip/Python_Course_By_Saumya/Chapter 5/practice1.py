# Create a dictionary named marks to store marks of 3 subjects.
# Add the subjects one by one and print the final dictionary

marks= {}
# print(type(marks))

marks["Maths"]= 99
marks["Chemistry"]= 99
marks["Computer Science"]= 91

print(marks)
