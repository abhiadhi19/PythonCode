food= {"paneer", "chole bathure", "sandwitch", "golgappe", "paneer"}
print(type(food))
print(food)
food.add("Kunafa")
print(food)
food.remove("chole bathure")
print(food)

# sets do not entertain duplicacy 

emptySet= set()
print(type(emptySet))
