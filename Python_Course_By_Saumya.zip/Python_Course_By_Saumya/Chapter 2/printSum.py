# input 2 numbers and print sum

input1= int(input("Enter first number"))
input2= int(input("Enter second number"))
sum= input1 + input2

print("Sum of the 2 values is", sum)