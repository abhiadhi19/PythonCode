# program to take age as input and print value entered and its data type 

age = input("Enter your age : ")
print("Value entered is :", age)
print("Data type is : ", type(age))