sweet= "Gulab Jamun"
game = "Badminton"


