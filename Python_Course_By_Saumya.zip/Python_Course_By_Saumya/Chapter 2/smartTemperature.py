# take input celsius 

celsius= float(input("Enter The Value: "))

# print fahrenheit equivalent of celsius 
fahren= (celsius*(9/5)) + 32

print("Fahrenheit value is: ", fahren)




