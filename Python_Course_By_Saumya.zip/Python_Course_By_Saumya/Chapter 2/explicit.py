# take num as input 
# convert to float and print both orginal & converted
# value with their data types 

num= input( "Enter a value : ")
convertedValue = float(num)

print("Orginal Value is ", num, "Data Type :", type(num))

print("Converted Value is ", convertedValue, "Data Type :", type(convertedValue))
