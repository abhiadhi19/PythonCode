food= "Samosa"
age= 25
area= 670.98
name= "Khushi"

print("Data type of variable name is", type(name))
print(type(area))