# arithmetic operators 

x= 10
y= 5

print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x%y)
print(x**y)

#comparison operators 

print(x==y) #false
print(x<y) #false
print(x>y) #true

# logical operators 

print("AND Operator Result ", x>y and x<y) #false
print("OR Operator Result ", x>y or x<y) #true
print("Not Operator Result", not(x>y)) #false

# Assignment operator 

a= 2
b= 3

a= a+6
a+=6


a= a-1
a-=1

a=a/10
a/=10

a=a*10
a*=10



