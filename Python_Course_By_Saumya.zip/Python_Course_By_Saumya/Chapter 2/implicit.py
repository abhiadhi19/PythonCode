#implicit conversion (automatically)
x= 5  #int
y= 10.5 #float
z= x+y #float 

print("answer is ", z)
print("data type of answer is ", type(z))


