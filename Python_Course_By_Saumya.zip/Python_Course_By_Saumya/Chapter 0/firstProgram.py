print("Hello World")

