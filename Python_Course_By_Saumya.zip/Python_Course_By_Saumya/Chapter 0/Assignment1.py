# Assignement Question : Print your name 10 times using * symbol and each time it should be on next line 

print(("Saumya Singh" + "\n") * 10)
